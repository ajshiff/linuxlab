class Date
{
   private:
   int month;
   int day;
   int year;
   public:
   void set(int, int, int);
   void displayAmerican();
   void displayEuropean();
   void displayISO();
};
